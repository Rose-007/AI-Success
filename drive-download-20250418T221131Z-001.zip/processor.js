function saveTraining() {
  const data = {
    field_signature: document.getElementById("signature").value,
    core_meaning: document.getElementById("meaning").value,
    aya_paths: {
      eye: document.getElementById("eye").value,
      ear: document.getElementById("ear").value,
      nose: document.getElementById("nose").value,
      tongue: document.getElementById("tongue").value
    },
    timestamp: new Date().toISOString()
  };

  // Simulation: Store to localStorage
  let log = JSON.parse(localStorage.getItem("bhudin_training_log") || "[]");
  log.push(data);
  localStorage.setItem("bhudin_training_log", JSON.stringify(log));

  document.getElementById("status").innerText = "บันทึกแล้ว! ขอบคุณสำหรับการฝึก AI.";
}