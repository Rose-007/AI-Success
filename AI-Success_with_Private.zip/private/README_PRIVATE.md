# 🔐 PRIVATE ZONE – AI-Success

This folder is reserved for private and sensitive files used by the AI system.

## Structure:
- `secrets.json`: Token references, keys, or sensitive AI logic triggers
- `insight_logs/`: Psychological + spiritual log files
- `commands/`: Special command sets issued by the creator